const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();

app.use(cors()); // 👈 allow cross-origin requests
app.use(express.json());
app.use(express.static(__dirname + '/public'));

// ✅ Save user edits permanently in `data.geojson
app.post('/save', (req, res) => {
    let newEdits = req.body;

    try {
        let existingData = { type: "FeatureCollection", features: [] };

        // Load existing saved edits (if data.geojson exists)
        if (fs.existsSync('data.geojson')) {
            existingData = JSON.parse(fs.readFileSync('data.geojson', 'utf-8'));
        }

        // Append new features to the saved edits
        existingData.features = existingData.features.concat(newEdits.features);

        // Save to `data.geojson`
        fs.writeFileSync('data.geojson', JSON.stringify(existingData, null, 2));

        console.log("✅ New edits saved successfully!");
        res.json({ status: 'saved' });
    } catch (error) {
        console.error("❌ Error saving edits:", error);
        res.status(500).json({ message: 'Error saving data' });
    }
});

// ✅ Start the server on port 3000
app.listen(3000, () => console.log('✅ Server running on port 3000'));



























// ✅ Save user edits to a GeoJSON file
//*app.post('/save', (req, res) => {
    //*const data = JSON.stringify(req.body, null, 2);

    //*console.log("✅ Received save request with data:", data); // Debugging log

    //*try {
            //*fs.writeFileSync('data.geojson', data);
            //*console.log("✅ Data successfully saved to data.geojson");
            //*res.json({ status: 'saved' });
            //*} catch (error) {
        //*console.error("❌ Error saving data:", error);
        //*res.status(500).json({ message: 'Error saving data' });
    //*}
//*});


// Load saved edits
//*app.get('/load', (req, res) => {
    //*if (!fs.existsSync('data.geojson')) {
        //*console.warn("⚠️ No data.geojson found, creating a new empty one...");
        //*fs.writeFileSync('data.geojson', JSON.stringify({ type: "FeatureCollection", features: [] }));
    //*}

    //*try {
            //*let data = fs.readFileSync('data.geojson', 'utf-8');
            //*console.log("✅ Loaded data from data.geojson:", data); // Debugging log
            //*res.json(JSON.parse(data));
        //*} catch (error) {
            //*console.error("❌ Error loading data:", error);
            //*res.status(500).json({ message: 'Error loading data' });
        //*}
    //*});


// Start the server on port 3000
//*app.listen(3000, () => console.log('✅ Server running on http://localhost:3000'));
